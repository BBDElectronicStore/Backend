"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const sqs_helper_1 = require("../helpers/sqs-helper");
const handler = async (event, context) => {
    try {
        const body = JSON.parse(event.body || '{}');
        const result = `Hello, ${body.name || 'World'}!`;
        await (0, sqs_helper_1.PublishMessage)({ message: result });
        return {
            statusCode: 200,
            body: JSON.stringify({ message: result }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error' }),
        };
    }
};
exports.handler = handler;
