"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishMessage = void 0;
const aws_sdk_1 = require("aws-sdk");
const sqs = new aws_sdk_1.SQS();
const queueUrl = process.env.SQS_QUEUE_URL;
const PublishMessage = async (object) => {
    if (!queueUrl) {
        throw new Error('SQS_QUEUE_URL is not defined');
    }
    const params = {
        QueueUrl: queueUrl,
        MessageBody: JSON.stringify(object),
    };
    return await new Promise((resolve, reject) => {
        sqs.sendMessage(params, (err, data) => {
            if (err) {
                reject(Error(err.message));
            }
            else {
                resolve(data);
            }
        });
    });
};
exports.PublishMessage = PublishMessage;
